<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('front.pages.dashboard-student.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <div class="container-fluid">
            <div class="row">  
                <div class="col-lg-3 p-0">
                    <div class="side-bar">
                    <?php echo $__env->make('front.pages.dashboard-student.inc.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="col-lg-9 p-0 main-cont">
                    <?php echo $__env->make('front.pages.dashboard-student.inc.header-ct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('front.pages.dashboard-student.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('front.pages.dashboard-student.inc.footer-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('jsContent'); ?>
    </body>
</html><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/app-student.blade.php ENDPATH**/ ?>