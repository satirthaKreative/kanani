<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('admin.dashboard.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <!-- begin app -->
    <div class="app">
        <!-- begin app-wrap -->
        <div class="app-wrap">
            <!-- begin pre-loader -->
            <div class="loader">
                <div class="h-100 d-flex justify-content-center">
                    <div class="align-self-center">
                        <img src="<?php echo e(asset('backend/assets/img/loader/loader.svg')); ?>" alt="loader"></div>
                </div>
            </div>
            <?php echo $__env->make('admin.dashboard.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- begin app-container -->
            <div class="app-container">
                <?php echo $__env->make('admin.dashboard.include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            <!-- end app-main -->
            </div>
            <?php echo $__env->make('admin.dashboard.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end footer -->
        </div>
        <!-- end app-wrap -->
    </div>
    <!-- end app -->
    <?php echo $__env->make('admin.dashboard.include.footer-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('adminjsContent'); ?>
</body>
</html>
<?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/admin/layouts/app-dashboard.blade.php ENDPATH**/ ?>