<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>

    <link rel="stylesheet" href="<?php echo e(asset('frontend/studentDashboard/css/bootstrap.min.css')); ?>" type="text/css">
    <link href="<?php echo e(asset('frontend/studentDashboard/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('frontend/studentDashboard/css/responsive.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('frontend/studentDashboard/css/slimNav_sk78.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/studentDashboard/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/studentDashboard/css/owl.theme.default.css')); ?>" type="text/css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/themes/redmond/jquery-ui.css" type="text/css">
</head>
<?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/pages/dashboard-student/inc/head.blade.php ENDPATH**/ ?>