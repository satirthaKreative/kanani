<?php    $link = $_SERVER['REQUEST_URI'];    ?>
<?php    $link_array = explode('/',$link);   ?>
<?php    $page = end($link_array);   ?>                
                <aside class="app-navbar">
                    <!-- begin sidebar-nav -->
                    <div class="sidebar-nav scrollbar scroll_light">
                        <ul class="metismenu " id="sidebarNav">
                            <li class="nav-static-title">Personal</li>
                            <li class="<?php if($page == 'admin'): ?> active <?php endif; ?>">
                                <a href="<?php echo e(route('admin.home')); ?>" aria-expanded="false">
                                    <i class="nav-icon ti ti-rocket"></i>
                                    <span class="nav-title">Dashboards</span>
                                </a>
                            </li>
                            <li class="<?php if($page == 'language'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Languages</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'language'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.language')); ?>">View languages</a> </li>
                                    <!-- <li> <a href="tables-color.html">Color Table </a> </li>
                                    <li> <a href="tables-datatable.html">Data Table</a> </li>
                                    <li> <a href="tables-editable.html">Editable Table</a> </li>
                                    <li> <a href="tables-export.html">Export Table</a> </li> -->
                                </ul>
                            </li>
                            <li class="<?php if($page == 'country'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Country</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'country'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.country')); ?>">View Countries</a> </li>
                                </ul>
                            </li>
                            <li class="<?php if($page == 'tutor'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Tutors</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'tutor'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.tutor')); ?>">View Tutors</a> </li>
                                </ul>
                            </li>
                            <li class="<?php if($page == 'free-trail' || $page == 'free-trail-config'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Free Trail</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'free-trail-config'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.show-config-free-trail')); ?>">Config Of Free Trail</a> </li>
                                    <li class="<?php if($page == 'free-trail'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.show-free-trail')); ?>">View Free Trail</a> </li>
                                </ul>
                            </li>
                            <li class="<?php if($page == 'student' || $page == 'student-booking' || $page == 'student-available-slot' || $page == 'student-available-interval-slot'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Student</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'student'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.student')); ?>">View Students</a> </li>
                                    <li class="<?php if($page == 'student-booking'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.student-booking')); ?>">View Booking</a> </li>
                                    <li class="<?php if($page == 'student-available-slot'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.student-available-slot')); ?>">View Available Slot</a> </li>
                                    <li class="<?php if($page == 'student-available-interval-slot'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.student-available-interval-slot')); ?>">Config Available Slot</a> </li>
                                </ul>
                            </li>
                            <li class="<?php if($page == 'course' || $page == 'course-package'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Course</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'course'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.course')); ?>">View Course</a> </li>
                                    <li class="<?php if($page == 'course-package'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.course-package')); ?>">Course Package</a> </li>
                                </ul>
                            </li>
                            <li class="<?php if($page == 'profile' || $page == 'contact'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Profile</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'profile'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.profile')); ?>">View Profile</a> </li>
                                    <li class="<?php if($page == 'contact'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.contact')); ?>">View Contact Details</a> </li>
                                </ul>
                            </li>
                            <li class="<?php if($page == 'choose-us'): ?> active <?php endif; ?>">
                                <a class="has-arrow" href="javascript:void(0)" aria-expanded="false"><i class="nav-icon ti ti-layout-column3-alt"></i><span class="nav-title">Choose Us</span></a>
                                <ul aria-expanded="false">
                                    <li class="<?php if($page == 'choose-us'): ?> active <?php endif; ?>"> <a href="<?php echo e(route('admin.choose-us')); ?>">View Choose Us</a> </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- end sidebar-nav -->
                </aside><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/admin/dashboard/include/nav.blade.php ENDPATH**/ ?>