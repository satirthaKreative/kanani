<?php $__env->startSection('content'); ?>
<div class="inner-ban"></div>
<section class="register-page">
    <img src="<?php echo e(asset('frontend/images/login-img2.png')); ?>" alt="" class="img1">
    <img src="<?php echo e(asset('frontend/images/contact-img3.png')); ?>" alt="" class="img2">
    <div class="container">
        <div class="sec">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Choose Account type</h2>
                </div>
                <div class="col-lg-4 col-md-4 ">                
                    <div class="decp">
                        <img src="<?php echo e(asset('frontend/images/reg-img1.svg')); ?>" alt="">
                        <h4>Child account</h4>
                        <p>For parents or guardians registering on behalf of a child</p>
                        <a href="<?php echo e(route('satirtha.childRegPage',base64_encode('child'))); ?>">Create a child account</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 ">                
                    <div class="decp">
                        <img src="<?php echo e(asset('frontend/images/reg-img2.svg')); ?>" alt="">
                        <h4>Teen account</h4>
                        <p>For teen learners</p>
                        <a href="<?php echo e(route('satirtha.childRegPage',base64_encode('teen'))); ?>">Create a Teen account</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 ">                
                    <div class="decp">
                        <img src="<?php echo e(asset('frontend/images/reg-img3.svg')); ?>" alt="">
                        <h4>adult account</h4>
                        <p>For adult learners</p>
                        <a href="<?php echo e(route('satirtha.childRegPage',base64_encode('adult'))); ?>">Create an adult account</a>
                    </div>
                </div>
               
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/layouts/pre-register.blade.php ENDPATH**/ ?>