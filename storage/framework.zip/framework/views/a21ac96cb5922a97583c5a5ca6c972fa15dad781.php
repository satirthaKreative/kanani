<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-12 pr-lg-4">
				<h2>Subscribe and stay updated!</h2>
				<p>Suspendisse dictum mattis eros at vehicula</p>
				<form action="">
					<input type="text" placeholder="Your Mail Address">
					<input type="submit" value="Subscribe">
				</form>
				<ul class="con">
					<li><a href="#"><i class="fas fa-phone-alt"></i> info@gmail.com</a></li>
					<li><a href="#"><i class="fas fa-envelope"></i> +102 665-6526</a></li>
				</ul>
			</div>
			<div class="col-lg col-md-4">
				<h3>Discover</h3>
				<ul class="mennu">
					<li><a href="#">About Us</a></li>
					<li><a href="#">Courses</a></li>
					<li><a href="#">Prices</a></li>
					<li><a href="#">Blogs</a></li>
				</ul>
			</div>
			<div class="col-lg col-md-4">
				<h3>Support</h3>
				<ul class="mennu">
					<li><a href="#">User Guide</a></li>
					<li><a href="#">FAQ</a></li>
					<li><a href="#">Contact Us</a></li>
				</ul>
			</div>
			<div class="col-lg col-md-4">
				<ul class="social">
					<li><a href="#"><i class="fab fa-facebook-f"></i> Facebook</a></li>
					<li><a href="#"><i class="fab fa-instagram"></i> instagram</a></li>
					<li><a href="#"><i class="fab fa-twitter"></i> twitter</a></li>
					<li><a href="#"><i class="fab fa-youtube"></i>youtube</a></li>
				</ul>
			</div>
			<div class="col-lg-12">
			<hr>
			</div>
			<div class="col-lg-6 col-md-6">
				<h6> © 2021 kananieducation All Rights Reserved</h6>
			</div>
			<div class="col-lg-6 col-md-6">
				<h5><a href="#">Privacy Policy </a> | <a href="#">Legal Notice </a> | <a href="#">Support</a></h5>
			</div>
		</div>
	</div>
</footer><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/include/footer.blade.php ENDPATH**/ ?>