<?php $__env->startSection('content'); ?>
<div class="my-account-page">
                <h2>Personal Information</h2>
                <form action="<?php echo e(route('satirtha.update-my-account')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="update_my_account_hidden_id" value="<?php echo e(Auth::user()->id); ?>">
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="">First name</label>
                            <input type="text" name="first_name" placeholder="John" value="<?php echo e(Auth::user()->first_name); ?>">
                        </div>
                        <div class="col-lg-6">
                            <label for="">Last name</label>
                            <input type="text" name="last_name" placeholder="Deo" value="<?php echo e(Auth::user()->last_name); ?>">
                        </div>
                        <div class="col-lg-6">
                            <label for="my-account-native-lang-id">Native language</label>
                            <select name="native_language_name" id="my-account-native-lang-id">
                                <option value="">Select language</option>
                                <?php $__currentLoopData = $getCountryQuery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <?php $languageActualName = $country->native_language; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $languageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($langList->id); ?>" <?php if($langList->id == $languageActualName): ?> selected <?php endif; ?>><?php echo e(ucwords($langList->language_name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="my-account-country-id">Country</label>
                            <select name="country_name" id="my-account-country-id">
                                <option value="">Select country</option>
                                <?php $__currentLoopData = $getCountryQuery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <?php $countryActualName = $country->country_name; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $countryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($counList->id); ?>" <?php if($counList->id == $countryActualName): ?> selected <?php endif; ?>><?php echo e($counList->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="">Email</label>
                            <input type="email" placeholder="Enter email address" value="<?php echo e(Auth::user()->email); ?>" name="user_email" readonly>
                        </div>
                        <div class="col-lg-12">
                            <input type="submit" value="Updated">
                        </div>
                    </div>
                </form>
                
                    <h2 id="account-settings">Account Settings</h2>
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Change Password</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">Change Email</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab">Delete Account</a>
                        </li>
                    </ul><!-- Tab panes -->
                    <div class="tab-content">
                        <div class="tab-pane active" id="tabs-1" role="tabpanel">
                            <form action="<?php echo e(route('satirtha.update-my-account-password')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="update_my_account_hidden_id" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="row">
                                <div class="col-lg-6">
                                    <label for="">Create password</label>
                                    <input type="password" name="create_password_name" placeholder="***********">
                                </div>
                                <div class="col-lg-6">
                                    <label for="">Confirm password</label>
                                    <input type="password" name="confirm_password_name" placeholder="***********">
                                </div>
                                <div class="col-lg-12">
                                    <input type="submit" value="Updated">
                                </div>
                            </div>
                            </form>
                        </div>
                        <div class="tab-pane" id="tabs-2" role="tabpanel">
                            <form action="<?php echo e(route('satirtha.update-my-account-email')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="update_my_account_hidden_id" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="row">
                                <div class="col-lg-12">
                                    <label for="">New Email Address</label>
                                    <input type="email" name="new_email_address_name" placeholder="@example.com">
                                </div>
                                <!-- <div class="col-lg-6">
                                    <label for="">Password</label>
                                    <input type="password" name="password" placeholder="***********">
                                </div> -->
                                <div class="col-lg-12">
                                    <input type="submit" value="Updated">
                                </div>
                            </div>
                            </form>
                        </div>
                        <div class="tab-pane" id="tabs-3" role="tabpanel">
                            <form action="<?php echo e(route('satirtha.delete-my-account')); ?>" id="delete-my-form" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="update_my_account_hidden_id" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="row">                                
                                <div class="col-lg-12">
                                    <h3>Delete your Account</h3>
                                    <input type="submit" id="delete-account-submit-id"  value="Delete Account">
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>


            </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsContent'); ?>
<script>
    $("#delete-account-submit-id").click(function(e){
        e.preventDefault();
        var x = confirm('Are you sure to delete your account? ');
        if(x)
        {
            document.getElementById("delete-my-form").submit();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app-student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/pages/dashboard-student/pages/my-account/my-account.blade.php ENDPATH**/ ?>