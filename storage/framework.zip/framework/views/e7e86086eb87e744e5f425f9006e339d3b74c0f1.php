<footer class="footer">
    <div class="row">
        <div class="col-12 col-sm-6 text-center text-sm-left">
            <p>&copy; Copyright 2021. All rights reserved.</p>
        </div>
        <div class="col  col-sm-6 ml-sm-auto text-center text-sm-right">
            <p><a target="_blank" href="javascript: ;">SATIRTHA DAS</a></p>
        </div>
    </div>
</footer>
<?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/admin/dashboard/include/footer.blade.php ENDPATH**/ ?>