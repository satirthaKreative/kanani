 
<?php $__env->startSection('content'); ?>
                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <!-- begin page title -->
                                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                                    <div class="page-title mb-2 mb-sm-0">
                                        <h1>Students</h1>
                                    </div>
                                    <div class="ml-auto d-flex align-items-center">
                                        <nav>
                                            <ol class="breadcrumb p-0 m-b-0">
                                                <li class="breadcrumb-item">
                                                    <a href="javascript:;"><i class="ti ti-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item">
                                                    Tables
                                                </li>
                                                <li class="breadcrumb-item active text-primary" aria-current="page">Students Table</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end page title -->
                            </div>
                        </div>
                        <!-- end row -->
                        <!-- begin row -->
                        <div class="row">
                            
                            <div class="col-lg-12">
                                <div class="card card-statistics">
                                    <div class="card-body">
                                        <div class="row mb-3">
                                            <!-- <div class="col-lg-12">
                                                <span>
                                                    <a class="btn btn-success text-white" onclick="add_tutor_modal_fx()">Add Student</a>
                                                </span>
                                            </div> -->
                                        </div>
                                        
                                        <div class="datatable-wrapper table-responsive">
                                            <table id="datatable" class="display compact table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Native Language</th>
                                                        <th>Country</th>
                                                        <th>Role Status</th>
                                                        <th>Status</th>
                                                        <!-- <th>Action</th> -->
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $studentQuery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e(ucwords($ck->first_name)); ?> <?php echo e(ucwords($ck->last_name)); ?></td>
                                                        <td><?php echo e(strtolower($ck->email)); ?></td>
                                                        <td><?php echo e(ucwords($ck->language_name)); ?></td>
                                                        <td><?php echo e(ucwords($ck->country_name)); ?></td>
                                                        <td>
                                                            <?php if($ck->user_role == 1): ?>
                                                                <?php $user_role = "<b class='text-warning'>Child</b>"; ?>
                                                            <?php elseif($ck->user_role == 2): ?>
                                                                <?php $user_role = "<b class='text-info'>Teen</b>"; ?>
                                                            <?php elseif($ck->user_role == 3): ?>
                                                                <?php $user_role = "<b class='text-danger'>Adult</b>"; ?>
                                                            <?php endif; ?>

                                                            <?php echo $user_role; ?>
                                                        </td>
                                                        <td>
                                                            <?php 
                                                                if($ck->account_status == "active"){
                                                                    $coun_state = "<b class='text-success'>Active</b>"; 
                                                                }else if($ck->account_status == "inactive"){
                                                                    $coun_state = "<b class='text-danger'>Inactive</b>"; 
                                                                }
                                                                echo $coun_state;
                                                            ?>
                                                        </td>
                                                        <!-- <td>
                                                            <?php 
                                                                if($ck->account_status == "active"){
                                                                    $update_state = "inactive"; 
                                                                }else if($ck->account_status == "inactive"){
                                                                    $update_state = "active"; 
                                                                }
                                                            ?>
                                                            <span class="text-info text-bold"><a href="javascript:;" onclick="student_edit_fx(<?php echo e($ck->id); ?>)" class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a></span> <span class="text-danger text-bold"><a href="javascript:;" class="btn btn-sm btn-danger" onclick="student_del_fx(<?php echo e($ck->id); ?>)"><i class="fa fa-trash"></i></a></span> <span class="text-info text-bold"><a href="javascript:;" class="btn btn-sm btn-success" onclick="student_change_state_fx(<?php echo e($ck->id); ?>,'<?php echo e($update_state); ?>')">Change Status</a></span>
                                                        </td> -->
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Native Language</th>
                                                        <th>Country</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end container-fluid -->
                </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminjsContent'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/admin/dashboard/pages/student/student.blade.php ENDPATH**/ ?>