<?php $__env->startSection('content'); ?>
<div class="inner-ban">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6">
                <h2 data-descr="Choose us">Why Choose us</h2>
            </div>
            <div class="col-lg-6 col-md-6">
                <ul>
                    <li><a href="<?php echo e(route('satirtha.home')); ?>">Home</a></li>
                    <li>Why Choose us</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<section class="Choose-page">
    <img src="<?php echo e(asset('frontend/images/choose-us3.png')); ?>" alt="" class="img2">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-7">
                <h2><span>Welcome</span> TO Kanani</h2>
                <p>Aliquam sit amet massa convallis nunc auctor ultrices ac vel magna. Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus. Fusce volutpat gravida augue eget hendrerit. Mauris sollicitudin cursus orci, vel pellentesque nisl pretium vel.</p>
                <p>“Do the difficult things while they are easy and do the great things while they are small. A journey of a thousand miles begins with a single step.”</p>
                <h6>Lao Tzu</h6>
            </div>
            <div class="col-lg-5 col-md-5">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/choose-us2.png')); ?>" alt="" class="img1">
                    <img src="<?php echo e(asset('frontend/images/choose-us-img1.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="Choose-page2">
    <img src="<?php echo e(asset('frontend/images/choose-us4.png')); ?>" alt="" class="img2">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/choose-us2.png')); ?>" alt="" class="img1">
                    <img src="<?php echo e(asset('frontend/images/choose-us5.jpg')); ?>" alt="" class="img3">
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <h2>Why choose us</h2>
                <p>We are committed to establishing high standard English speakers through quality integral education and critical comprehension by diverse methods of teaching the English language, be it spoken or written. We envision a society of fluent, excellent speakers in a successful community molded by different methods of English teaching.</p>
                <ul>
                    <li>Integer sed velit urna. Ut luctus egestas orci eu mattis</li>
                    <li>Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus</li>
                    <li>Mauris sollicitudin cursus orci, vel pellentesque nisl pretium vel. Ut sed augue malesuada</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="Choose-page3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Benefits of Learning English</h2>
                <p>Rutrum lacus tempor. Integer sed velit urna. Ut luctus egestas orci eu mattis. Ut eu mauris condimentum, sollicitudin metus vel, tempor dolor. Suspendisse dictum mattis eros at </p>
            </div> 
            <div class="col-lg-4 col-md-4">
            <img src="<?php echo e(asset('frontend/images/choose-us7.jpg')); ?>" alt="">
                    <div class="decp">
                        <h3>One-To-one online classs</h3>
                        <ul>
                            <li>Integer sed velit urna. Ut luctus egestas orci eu mattis</li>
                            <li>Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus</li>
                        </ul>
                    </div>
            </div>  
            <div class="col-lg-4 col-md-4">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/choose-us8.jpg')); ?>" alt="">
                    <div class="decp">
                        <h3>Instant feedback, monitor track</h3>
                        <ul>
                            <li>Integer sed velit urna. Ut luctus egestas orci eu mattis</li>
                            <li>Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus</li>
                        </ul>
                    </div>
                </div>
            </div> 
            <div class="col-lg-4 col-md-4">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/choose-us9.jpg')); ?>" alt="">
                    <div class="decp">
                        <h3>Learn english whenever you want</h3>
                        <ul>
                            <li>Integer sed velit urna. Ut luctus egestas orci eu mattis</li>
                            <li>Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus</li>
                        </ul>
                    </div>
                </div>
            </div>   
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/pages/other-pages/choose-us.blade.php ENDPATH**/ ?>