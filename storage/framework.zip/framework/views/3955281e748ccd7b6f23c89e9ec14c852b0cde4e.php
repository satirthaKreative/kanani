    <header>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3 col-4 logo-sec">
                    <a href="<?php echo e(route('satirtha.home')); ?>"><img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt=""></a>
                </div>
                <div class="col-lg-9 col-8 menu-sec text-right">
                    <div id="navigation">
                        <nav>
                            <ul>
                                <li class="current-menu-item"><a href="<?php echo e(route('satirtha.home')); ?>">Home</a></li>
                                <li><a href="<?php echo e(route('satirtha.choose-us')); ?>"> Why choose us</a></li>
                                <li>
                                    <a href="#">Courses <i class="fal fa-angle-down"></i></a>
                                    <ul class="sub-menu">
                                        <li><a href="#">kids english courses </a></li>
                                        <li><a href="#">Teens english courses</a></li>
                                        <li><a href="#">adults english courses</a></li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo e(route('satirtha.contact')); ?>">Contact Us</a></li>
                            </ul>
                        </nav>
                    </div>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('satirtha.show-course-page')); ?>" class="login-but"><i class="fas fa-user"></i>Dashboard</a>
                        <?php else: ?>
                            <!-- <a href="">Login</a> -->
                            <a href="<?php echo e(route('login')); ?>" class="login-but"><i class="fas fa-user"></i> Login/Register</a>
                            <?php if(Route::has('register')): ?>
                                <!-- <a href="<?php echo e(route('register')); ?>">Register</a> -->
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/include/header.blade.php ENDPATH**/ ?>