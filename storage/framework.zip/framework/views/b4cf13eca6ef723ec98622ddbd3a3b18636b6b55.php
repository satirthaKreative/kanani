<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('front.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <?php echo $__env->make('front.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('front.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('front.include.footer-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('jsContent'); ?>
    </body>
</html><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/app.blade.php ENDPATH**/ ?>