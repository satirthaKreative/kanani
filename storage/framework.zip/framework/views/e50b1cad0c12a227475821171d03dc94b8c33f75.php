<?php $__env->startSection('content'); ?>
            <div class="my-account-page booking-page">
                <form action="<?php echo e(route('satirtha.submit-booking-from-student')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                       <div class="col-lg-8">
                           <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Course packages</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">2 Days a week</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab">3 Days a week</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-4" role="tab">5 Days a week</a>
                            </li>
                        </ul><!-- Tab panes -->
                       </div>
                       <div class="col-lg-4">
                            <div class="coursetype">
                                <label for="">Course type</label>
                                <select name="" id="">
                                    <option value="">English conversation course</option>
                                </select>
                            </div>
                       </div>
                    </div>

                   <div class="row">
                    <div class="col-lg-12">
                        <div class="tab-content">
                        <div class="tab-pane active" id="tabs-1" role="tabpanel">
                             <table>
                                  <tr>
                                    <th>Time</th>
                                    <th>Packages</th>
                                    <th>Lessons</th> 
                                    <th>Package</th> 
                                    <th>Price</th> 
                                    <th></th>                     
                                  </tr>
                                  
                                  <?php $i = 1; ?>
                                  <?php $__currentLoopData = $courseDBsubQuery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseSubQ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($courseSubQ->times_in_minutes); ?> mins</td>
                                        <td><?php echo e(ucwords($courseSubQ->topic_name)); ?> <br/><sub><?php echo e(ucwords($courseSubQ->course_name)); ?></sub></td>
                                        <td><?php echo e($courseSubQ->no_of_lessons); ?></td>
                                        <td>
                                            <select name="choose_a_package_name<?php echo e($i); ?>" id="choose-a-package-id<?php echo e($i); ?>" onchange="choose_package_fx(<?php echo e($i); ?>,<?php echo e($courseSubQ->id); ?>)">
                                                <option value="">Choose a package</option>
                                                <?php $__currentLoopData = $role_wish_price_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coursePackQuery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($coursePackQuery->id); ?>"><?php echo e($coursePackQuery->no_of_lessons_per_month); ?> lessons a month <?php echo e($coursePackQuery->price_per_month); ?>$</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>   
                                        <td><a href="#" id="package-price-id<?php echo e($i); ?>">$0.00</a></td>      
                                        <td>
                                            <div class="custom-radio">
                                                <input class="custom-radio__control" onclick="package_booking_radio_fx(<?php echo e($i); ?>)" id="r<?php echo e($i); ?>" name="custom-radio" type="radio" value="male">
                                                <label class="custom-radio__label" for="r<?php echo e($i); ?>"></label>
                                            </div>
                                        </td>              
                                    </tr>
                                    <?php $i++; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </table>
                        </div>
                        <div class="tab-pane" id="tabs-2" role="tabpanel">
                            
                        </div>
                        <div class="tab-pane" id="tabs-3" role="tabpanel">
                            
                        </div>
                        <div class="tab-pane" id="tabs-4" role="tabpanel">
                            
                        </div>
                       
                      </div>
                    </div>                        
                   </div>
                   <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                                <input type="hidden" name="booking_interval_hidden_time_name" id="booking-interval-hidden-time-id">
                                <input type="hidden" name="paypal_package_name" id="paypal-package-id" />
                                <input type="hidden" name="paypal_package_radio_name" id="paypal-package-radio-id" />
                                <input type="hidden" name="paypal_package_price_name" id="paypal-package-price-id" />
                                <input type="hidden" name="lessons_per_week_count_hidden_name" id="lessons-per-week-count-hidden-id">
                                <div class="col-lg-12 booking-dates-for-count-class"></div>
                                <div class="col-lg-12">
                                    <label for="course-comment-id">Comment</label>
                                    <textarea name="course_comment_name" id="course-comment-id" placeholder="Your comment"></textarea> 
                                </div>                            
                                <div class="col-lg-4">
                                    <input type="submit" class="paypal" value="Paypal">
                                </div>
                                <div class="col-lg-4">
                                    <a href="#" class="cardbtn"><img src="<?php echo e(asset('frontend/studentDashboard/images/card.png')); ?>" alt="">Debit or Credit card</a>
                                </div>
                                <div class="col-lg-4">
                                    <a href="#" class="cancel_btn">Cancel</a>
                                </div>
                        </div>
                    </div>                        
                    </div>
                </form>
            </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsContent'); ?>
<script>
    $(function(){
        course_start_date_class_fx();
        $.ajax({
            url: "<?php echo e(route('satirtha.price-list-for-booking')); ?>",
            type: "GET",
            dataType: "json",
            success: function(event){

            }, error: function(event){

            }
        });
    });

    function available_booking_date_fx()
    {
        $.ajax({
            url: "<?php echo e(route('satirtha.show-student-available-calender')); ?>",
            type: "GET",
            dataType: "json",
            success: function(event){
            var disabledDates = event;
            $(".course-start-date-class").datepicker({
                dateFormat: 'dd-mm-yy',
                defaultDate: -1,
                minDate: new Date(),
                maxDate: +29,
                firstDay: 1,
                changeMonth: true,
                changeYear: true,
                beforeShowDay: function(date) {
                    var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
                    return [disabledDates.indexOf(string) == -1]
                }

            });
            }, error: function(event){

            }
        })  
    }

    function course_start_date_class_fx()
    {
        $(".course-start-date-class").datepicker({
            dateFormat: 'dd-mm-yy',
            defaultDate: -1,
            minDate: new Date(),
        });
    }

    function package_booking_radio_fx(i_val)
    {
        var choose_pack_id = $("#choose-a-package-id"+i_val).val();
        $("#paypal-package-radio-id").val(1);
        $.ajax({
            url: "<?php echo e(route('satirtha.package-checking-for-days')); ?>",
            type: "GET",
            data: {choose_pack_id: choose_pack_id},
            dataType: "json",
            success: function(event){
                $(".booking-dates-for-count-class").html(event.package_for_days);
                $("#lessons-per-week-count-hidden-id").val(event.lessons_per_Week_name);
                // course_start_date_class_fx();
                available_booking_date_fx();
            }, error: function(event){

            }
        });
        if(choose_pack_id == "" || choose_pack_id == null)
        {
            $("#paypal-package-radio-id").val(0);
            error_pass_alert_show_msg("Please choose a package first");
            $("#paypal-package-price-id").val(0);
            $("#package-price-id"+i_val).html("0.00"+"$");
            $("#r"+i_val).prop('checked',false);
        }
    }

    function choose_package_fx(id, course_id)
    {
        var choose_package = $("#choose-a-package-id"+id).val();
        $.ajax({
            url: "<?php echo e(route('satirtha.package-checking-for-days')); ?>",
            type: "GET",
            data: {choose_pack_id: choose_package},
            dataType: "json",
            success: function(event){
                $(".booking-dates-for-count-class").html(event.package_for_days);
                $("#lessons-per-week-count-hidden-id").val(event.lessons_per_Week_name);
                // course_start_date_class_fx();
                available_booking_date_fx();
            }, error: function(event){

            }
        });
        if(choose_package == "" || choose_package == null)
        {
            $("#paypal-package-radio-id").val(0);
            $("#paypal-package-price-id").val(0);
            $("#package-price-id"+id).html("$"+"0.00");
            $("#r"+id).prop('checked',false);
        }
        $("#paypal-package-id").val(choose_package);
        $.ajax({
            url: "<?php echo e(route('satirtha.change-package-for-booking-slot')); ?>",
            type: "GET",
            data: {id: choose_package, course_id: course_id},
            dataType: "json",
            success: function(event){
                $("#paypal-package-radio-id").val(1);
                $("#package-price-id"+id).html("$"+event);
                $("#paypal-package-price-id").val(event);
            }, error: function(event){

            }
        })
    }

    function course_class_start_time_fx(i_val)
    {
        var course_start_time = $("#course-class-start-time-id"+i_val).val();
        $.ajax({
            url: "<?php echo e(route('satirtha.get-end-client-choose-time')); ?>",
            type: "GET",
            data: {course_start_time: course_start_time},
            dataType: "json",
            success: function(event){
                $("#course-class-end-time-id"+i_val).val(event);
            }, error: function(event){

            }
        })
    }

    function avail_check(i_val)
    {
        var avail_checked_date = $("#course-start-date-id"+i_val).val();
        $.ajax({
            url: "<?php echo e(route('satirtha.show-student-available-calender-time-checked-date')); ?>",
            type: "GET",
            data: {avail_checked_date: avail_checked_date},
            dataType: "json",
            success: function(event){
                $("#avail-date-time-id"+i_val).html(event.whole_main_time);
                $("#booking-interval-hidden-time-id").val(event.interval_time_of_date);
            }, error: function(event){

            }
        })
    }

    function booking_class_previous_time_found_fx(i_val){
        var avail_time = $("#avail-date-time-id"+i_val).val();
        var interval_time = $("#booking-interval-hidden-time-id").val();
        $.ajax({
            url: "<?php echo e(route('satirtha.booking-class-previous-time-found')); ?>",
            type: "GET",
            data: { avail_time: avail_time, interval_time: interval_time },
            dataType: "json",
            success: function(event){
                $("#course-class-start-time-id"+i_val).val(event);
            }, error: function(event){

            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app-student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/pages/dashboard-student/pages/booking/booking.blade.php ENDPATH**/ ?>