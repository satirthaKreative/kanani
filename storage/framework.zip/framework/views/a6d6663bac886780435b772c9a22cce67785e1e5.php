<!DOCTYPE html>
<html>
    <div style="border:1px solid red;border-radius:5px;padding:10px;box-size:border-box;">
        <h1>Your tutor account credentials<h1>
        <p style="font-size:15px;line-height:25px;">
            <?php echo $details['body'] ?>
        </p>
    </div>
</html><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/emails/tutorRegEmail.blade.php ENDPATH**/ ?>