<!--  <a href="#0" class="cd-top"><i class="fa fa-angle-up" aria-hidden="true"></i></a>     -->
<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.slimNav_sk78.min.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {	
	$('#navigation nav').slimNav_sk78();		
	var owl = $('.students-say');
	owl.owlCarousel({
	autoPlay: 4000, //Set AutoPlay to 3 seconds
	items:1,	
	nav:true,  
	dots:false,
	loop:false,
	autoplay:true,
	smartSpeed:1500,
	autoplayTimeout:4000,
	});
	$('.accordion').find('.accordion-toggle').click(function() {
		$(this).next().slideToggle('600');
		$(".accordion-content").not($(this).next()).slideUp('600');
	});
	$('.accordion-toggle').on('click', function() {
		$(this).toggleClass('active').siblings().removeClass('active');
	});
});
</script>
<?php if(Session::has('success_msg')): ?>
<script>
    swal({
      title: "Successful!",
      text: "<?php echo e(Session::get('success_msg')); ?>",
      icon: "success",
      button: false,
      timer: 3000
    });
</script>
<?php endif; ?>
<!-- error alert -->
<?php if(Session::has('error_msg')): ?>
<script>
    swal({
      title: "Error!",
      text: "<?php echo e(Session::get('error_msg')); ?>",
      icon: "error",
      button: false,
      timer: 3000
    });
</script>
<?php endif; ?>

<script>
  // success msg
  function success_pass_alert_show_msg(alert_main_msg)
  {
    swal({
      title: "Successful!",
      text: alert_main_msg,
      icon: "success",
      button: false,
      timer: 3000
    });
  }
  // unique visitor
  function count_alert_unique_visitor(today_count, total_count, today_c, total_c)
  {
    var tStatus = "success";
    if(parseInt(today_c) == parseInt(0))
    {
      tStatus = "warning";
    }
    swal({
      title: today_count,
      text: total_count,
      icon: tStatus,
      button: "Ok",
      // timer: 3000
    });
  }
  // error msg
  function error_pass_alert_show_msg(alert_main_msg)
  {
    swal({
      title: "Error!",
      text: alert_main_msg,
      icon: "error",
      button: false,
      timer: 3000
    });
  }
</script><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/include/footer-js.blade.php ENDPATH**/ ?>