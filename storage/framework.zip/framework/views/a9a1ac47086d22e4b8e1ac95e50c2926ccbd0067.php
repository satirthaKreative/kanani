<?php $__env->startSection('content'); ?>
          <div class="course-page message-page">
                <div class="row">
                    <div class="col-lg-8">
                    <div class="sec2">                   
                       <table>
                          <tr>
                            <th>No</th>
                            <th>Subject</th>
                            <th>Total messages</th>
                            <th>Date</th>                        
                          </tr>
                          <tr>
                            <td>#1</td>
                            <td>Spken english lession 2</td>
                            <td>22 Messages</td>
                            <td>25/10/2021 - 11:20 AM</td>                       
                          </tr>
                          <tr>
                            <td>#2</td>
                            <td>Spken english lession 2</td>
                            <td>22 Messages</td>
                            <td>25/10/2021 - 11:20 AM</td>                       
                          </tr>
                          <tr>
                            <td>#3</td>
                            <td>Spken english lession 2</td>
                            <td>22 Messages</td>
                            <td>25/10/2021 - 11:20 AM</td>                       
                          </tr>
                          <tr>
                            <td>#4</td>
                            <td>Spken english lession 2</td>
                            <td>22 Messages</td>
                            <td>25/10/2021 - 11:20 AM</td>                       
                          </tr>
                          <tr>
                            <td>#5</td>
                            <td>Spken english lession 2</td>
                            <td>22 Messages</td>
                            <td>25/10/2021 - 11:20 AM</td>                       
                          </tr>
                          <tr>
                            <td>#6</td>
                            <td>Spken english lession 2</td>
                            <td>22 Messages</td>
                            <td>25/10/2021 - 11:20 AM</td>                       
                          </tr>                          
                      </table>
                     </div>                     
                    </div>
                    <div class="col-lg-4">
                        <div class="sec3">
                            <h2>Phasellus malesuada posuere purus</h2>
                            <a href="#">Got a Question?</a>
                            <a href="javascript: ;" onclick="contact_teacher_modal_fx()">Contact Teacher</a>
                         </div>
                    </div>
                </div>                
            </div>


<!-- The free trail class Modal -->
<div class="modal" id="free-trail-class-modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Free Trail Class</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo e(route('satirtha.free-trail-class-booking')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="age-scale-id">Age:</label>
            <select class="form-control"  id="age-scale-id" name="age_scale_name" required>
              <option value="">Choose a age</option>
              <?php for($i = 2; $i < 81; $i++): ?>
                <?php if($i < 10): ?>
                  <?php $age_limit = "0".$i; ?>
                <?php else: ?>
                  <?php $age_limit = $i; ?>
                <?php endif; ?>
                <option value="<?php echo e($i); ?>"><?php echo e($age_limit); ?> years</option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="english-learn-scale-id">English Level:</label>
            <select class="form-control"  id="english-learn-scale-id" name="english_learn_scale_name" required>
              <option value="">Choose a learning scale</option>
              <?php $__currentLoopData = $learningTypeQuery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $learningData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($learningData->id); ?>"><?php echo e($learningData->learning_scale_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
            <label for="avail-date-id">Date:</label>
            <input type="text" class="form-control" onkeydown="return false" name="avail_date_name" id="avail-date-id" onchange="avail_check()">
          </div>
          <div class="form-group">
            <label for="avail-date-id">Time:</label>
            <select class="form-control" name="avail_date_time_name" id="avail-date-time-id">
                <option value="">Choose time</option>
            </select>
          </div>
          <div class="form-group">
            <label for="leave-msg-id">Leave A Message:</label>
            <textarea class="form-control"  id="leave-msg-id" name="leave_msg_name" placeholder="Leave your message" rows="5" required></textarea>
          </div>
          <input type="hidden" name="hidden_interval_time_name" id="hidden-interval-time-name-id" value="0">
          <button type="submit" class="btn btn-primary">Submit</button> <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- end of message modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsContent'); ?>
<script>

  $(function() {
      $.ajax({
        url: "<?php echo e(route('satirtha.show-message-calender')); ?>",
        type: "GET",
        dataType: "json",
        success: function(event){
          var disabledDates = event;
          $("#avail-date-id").datepicker({
              dateFormat: 'dd-mm-yy',
              defaultDate: -1,
              minDate: new Date(),
              maxDate: +29,
              firstDay: 1,
              changeMonth: true,
              changeYear: true,
              beforeShowDay: function(date) {
                var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
                return [disabledDates.indexOf(string) == -1]
              }

          });
        }, error: function(event){

        }
      })  
    })

  function avail_check()
  {
    var avail_checked_date = $("#avail-date-id").val();
    $.ajax({
      url: "<?php echo e(route('satirtha.show-time-using-date')); ?>",
      type: "GET",
      data: {avail_checked_date: avail_checked_date},
      dataType: "json",
      success: function(event){
        $("#avail-date-time-id").html(event.whole_main_time);
        $("#hidden-interval-time-name-id").val(event.interval_time_of_date);
      }, error: function(event){

      }
    })
  }

  function contact_teacher_modal_fx()
  {
    $("#free-trail-class-modal").modal('show');
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app-student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/pages/dashboard-student/pages/message/message.blade.php ENDPATH**/ ?>