<?php $__env->startSection('content'); ?>
<style>
.invalid-feedback {
    display: block;
    width: 100%;
    margin-top: 0.25rem;
    font-size: 80%;
    color: #dc3545;
}

.is-invalid {
    border-color: #dc3545 !important;
    background-repeat: no-repeat;
    background-position: center right calc(0.375em + 0.1875rem);
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
}
</style>
<div class="inner-ban"></div>
<section class="login-page">
    <img src="<?php echo e(asset('frontend/images/login-img2.png')); ?> " alt="" class="img1">
    <img src="<?php echo e(asset('frontend/images/contact-img3.png')); ?>" alt="" class="img2">
    <div class="container">
        <div class="sec">
            <div class="row align-items-center">
                <div class="col-lg-5 col-md-5 p-0">
                
                    <div class="decp">
                        <img src="<?php echo e(asset('frontend/images/login-img1.png')); ?>" alt="">
                        <h2>Welcome Back</h2>
                        <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                        <h5>Don’t have an account?  <a href="<?php echo e(route('satirtha.preReg')); ?>">Student Sign up</a></h5>
                        <h3>Log in to <span>Kanani</span></h3>
                        <label for="">Email Address</label>
                        <input id="email" type="text" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="johndeo@gmail.com" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <label for="">Password</label>
                        <input id="password" type="password" class="<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="**********" name="password" required autocomplete="current-password">
                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <div class="row align-items-center">
                            <div class="col-lg-6 col-6 col-md-6">
                                <h6> <input type="checkbox" name="" id=""> Remember Me</h6>
                            </div>
                            <div class="col-lg-6 col-6 col-md-6">
                                <a href="forgot-password.php" class="fg-pass">Forgot Your Passowrd?</a>
                            </div>
                        </div>
                       <input type="submit" value="Log In">
                    </form>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/auth/login.blade.php ENDPATH**/ ?>