<!DOCTYPE html>
<html>
    <div style="border:1px solid red;border-radius:5px;padding:10px;box-size:border-box;">
        <h1>Account Activation<h1>
        <p style="font-size:15px;line-height:25px;">
            Your account activation link is : <?php echo e($details['body']); ?>

        </p>
    </div>
</html><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/emails/childRegEmail.blade.php ENDPATH**/ ?>