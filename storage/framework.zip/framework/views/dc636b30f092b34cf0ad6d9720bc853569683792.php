<?php $__env->startSection('content'); ?>
<style>
    .invalid-error-msg{
        padding: 10px 0px;
        background: #eee;
    }
</style>
<div class="inner-ban"></div>
<section class="register-page1">
        <?php if($decodeNewUserArr['role_type_data'] == "child"): ?>
            <img src="<?php echo e(asset('frontend/images/kids-img.png')); ?>" alt="" class="img1">
        <?php endif; ?>
        <?php if($decodeNewUserArr['role_type_data'] == "teen"): ?>
            <img src="<?php echo e(asset('frontend/images/teen-img.png')); ?>" alt="" class="img1">
        <?php endif; ?>
        <?php if($decodeNewUserArr['role_type_data'] == "adult"): ?>
            <img src="<?php echo e(asset('frontend/images/adult-img.png')); ?>" alt="" class="img1">
        <?php endif; ?>
    <img src="<?php echo e(asset('frontend/images/contact-img3.png')); ?>" alt="" class="img2">
    <div class="container">
        <div class="sec">
            <div class="row align-items-center">
               <div class="col-lg-6 col-md-6">
                   <h2>Create a <?php echo e($decodeNewUserArr['role_type_data']); ?> account</h2>
               </div>
               <div class="col-lg-6 col-md-6">
                   <h6>Already have an account? <a href="<?php echo e(route('login')); ?>">Log in</a></h6>
               </div>
               <div class="col-lg-12">
                   <h4><?php echo e(ucwords($decodeNewUserArr['role_type_data'])); ?>’s information</h4>
               </div>               
            </div>
            <form action="<?php echo e(route('satirtha.childRegSubmit')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                   <div class="row">
                       <input type="hidden" name="type_hidden_role_name" id="type-hidden-role-id" value="<?php echo e($decodeNewUserArr['role_type_id']); ?>" />
                       <div class="col-lg-6">
                           <label for="child-first-id"><?php echo e(ucwords($decodeNewUserArr['role_type_data'])); ?>’s first name</label>
                           <input type="text" placeholder="First Name" id="child-first-id" name="child_first_name" required>
                       </div>
                       <div class="col-lg-6">
                           <label for="child-last-id"><?php echo e(ucwords($decodeNewUserArr['role_type_data'])); ?>’s last name</label>
                           <input type="text" name="child_last_name" placeholder="Last Name" id="child-last-id" required>
                       </div>
                       <div class="col-lg-6">
                           <label for="child-native-lang-id">Native language</label>
                           <select name="native_lang_name" id="child-native-lang-id" required>
                                <option value="">Select language</option>
                                <?php $__currentLoopData = $languageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lang->id); ?>"><?php echo e($lang->language_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                       </div>
                       <div class="col-lg-6">
                           <label for="child-country-id">Country</label>
                           <select name="country_name" id="child-country-id" required>
                               <option value="">Select country</option>
                                <?php $__currentLoopData = $countryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                       </div>
                       <div class="col-lg-12">
                        <h4>Account information</h4>
                       </div>
                       <div class="col-lg-6">
                           <label for="child-user-id">Create username</label>
                           <input type="text" name="child_username" id="child-user-id" placeholder="@John434" autocomplete="off" required>
                       </div>
                       <div class="col-lg-6">
                           <label for="child-email-id">Parent/guardian email address</label>
                           <input type="text" name="child_useremail" id="child-email-id" placeholder="Enter email address" autocomplete="off" required>
                       </div>
                       <div class="col-lg-6">
                           <label for="child-pass-id">Create password</label>
                           <input type="password" required name="child_user_pass" id="child-pass-id" placeholder="*******" autocomplete="off">
                       </div>
                       <div class="col-lg-6">
                           <label for="child-cpass-id">Confirm password</label>
                           <input type="password" required name="child_user_cpass" id="child-cpass-id" placeholder="*******" autocomplete="off">
                       </div>
                       <div class="col-lg-12">
                           <h5> <input type="checkbox" checked required name="" id=""> By clicking Continue with or Sign up, you agree to kanani education <a href="#">Terms of Service and Privacy Policy</a></h5>
                           <h5> <input type="checkbox" checked required name="" id=""> Send me a monthly newsletter</h5>
                       </div>
                       <div class="col-lg-6 col-md-6">
                           <!-- <img src="<?php echo e(asset('frontend/images/recap.png')); ?>" alt=""> -->
                       </div>
                       <div class="col-lg-6 col-md-6">
                           <input type="submit" value="Create account">
                       </div>
                   </div>
                </form>
                <?php if(Session::has('status')): ?>
                <div class="row">
                    <div class="col-lg-12 mt-3 text-danger invalid-error-msg">
                        <div class="alert alert-danger">
                            <center>Demo <?php echo e(session('status')); ?> </center>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/layouts/child-register.blade.php ENDPATH**/ ?>