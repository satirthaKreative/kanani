<?php $__env->startSection('content'); ?>
<div class="banner-sec">
    <svg id="wave" style="transform:rotate(0deg); transition: 0.3s" viewBox="0 0 1440 100" version="1.1"
        xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="sw-gradient-0" x1="0" x2="0" y1="1" y2="0">
                <stop stop-color="rgba(243, 106, 62, 1)" offset="0%"></stop>
                <stop stop-color="rgba(255, 179, 11, 1)" offset="100%"></stop>
            </linearGradient>
        </defs>
        <path style="transform:translate(0, 0px); opacity:1" fill="url(#sw-gradient-0)"
            d="M0,0L60,15C120,30,240,60,360,75C480,90,600,90,720,76.7C840,63,960,37,1080,28.3C1200,20,1320,30,1440,43.3C1560,57,1680,73,1800,80C1920,87,2040,83,2160,76.7C2280,70,2400,60,2520,50C2640,40,2760,30,2880,36.7C3000,43,3120,67,3240,75C3360,83,3480,77,3600,61.7C3720,47,3840,23,3960,23.3C4080,23,4200,47,4320,60C4440,73,4560,77,4680,65C4800,53,4920,27,5040,16.7C5160,7,5280,13,5400,23.3C5520,33,5640,47,5760,50C5880,53,6000,47,6120,50C6240,53,6360,67,6480,75C6600,83,6720,87,6840,81.7C6960,77,7080,63,7200,51.7C7320,40,7440,30,7560,23.3C7680,17,7800,13,7920,25C8040,37,8160,63,8280,65C8400,67,8520,43,8580,31.7L8640,20L8640,100L8580,100C8520,100,8400,100,8280,100C8160,100,8040,100,7920,100C7800,100,7680,100,7560,100C7440,100,7320,100,7200,100C7080,100,6960,100,6840,100C6720,100,6600,100,6480,100C6360,100,6240,100,6120,100C6000,100,5880,100,5760,100C5640,100,5520,100,5400,100C5280,100,5160,100,5040,100C4920,100,4800,100,4680,100C4560,100,4440,100,4320,100C4200,100,4080,100,3960,100C3840,100,3720,100,3600,100C3480,100,3360,100,3240,100C3120,100,3000,100,2880,100C2760,100,2640,100,2520,100C2400,100,2280,100,2160,100C2040,100,1920,100,1800,100C1680,100,1560,100,1440,100C1320,100,1200,100,1080,100C960,100,840,100,720,100C600,100,480,100,360,100C240,100,120,100,60,100L0,100Z">
        </path>
    </svg>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6">
                <h6>Knowledge First</h6>
                <h2>The Largest Collection <span>Of Courses </span> </h2>                 
                <p>Student Registration and Administration Nemo enim ipsam voluptatem quia voluptas sit atur aut odit
                    aut fugit, sed quia consequuntur magni res.</p>
                <a href="#">Register Now</a>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="img-wrap">
                    <div class="sec1">
                        <h3><i class="fas fa-book-open"></i> 10K <span>Actice Students</span></h3>
                    </div>
                    <img src="<?php echo e(asset('frontend/images/ban-img.jpg')); ?>" alt="">
                    <div class="sec2">
                        <i class="fas fa-clipboard-check"></i>
                        <h5>Weekly Spent Hours</h5>
                        <h6>40 Hrs 30 mins</h6>
                        <img src="<?php echo e(asset('frontend/images/bar-img.svg')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="body-cont1">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6">
                <div class="img-wrap">
                    <div class="sec1">
                        <h3><i class="far fa-users"></i> The Best Learn <span>150 Best Teachers</span></h3>
                    </div>
                    <img src="<?php echo e(asset('frontend/images/home-img1.jpg')); ?>" alt="">
                    <div class="sec2">
                        <i class="fas fa-clipboard-check"></i>
                        <img src="<?php echo e(asset('frontend/images/thumb1.jpg')); ?>" alt="">
                        <h5>Anna Bell</h5>
                        <h6>Master of Education</h6>
                        <ul>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 pl-lg-5 col-md-6">
                <h6>About Us</h6>
                <h2>Welcome TO <span>Kanani</span> </h2>
                <p>Student Registration and Administration Nemo enim ipsam voluptatem quia voluptas sit atur aut odit
                    aut fugit, sed quia consequuntur magni res eos qui ratione voluptatem sequi nesciunt. There are many
                    variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some
                    form, by injected humour, or randomised believable.</p>
                <p>Consequuntur magni res eos qui ratione voluptatem sequi nesciunt. There are many variations of
                    passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by
                    injected humour, or randomised believable.</p>
                <a href="#">Know More</a>
            </div>
        </div>
    </div>
</section>

<section class="body-cont-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <i class="fal fa-book-open"></i>
                <h2>How it works</h2>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/home-img2.svg')); ?>" alt="">
                    <h4>Install Zoom</h4>
                    <p>There are many variations of passages of Lorem Ipsum available</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/home-img3.svg')); ?>" alt="">
                    <h4>Join Free Class</h4>
                    <p>There are many variations of passages of Lorem Ipsum available</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/home-img4.svg')); ?>" alt="">
                    <h4>Select Course</h4>
                    <p>There are many variations of passages of Lorem Ipsum available</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="wrap">
                    <img src="<?php echo e(asset('frontend/images/home-img5.svg')); ?>" alt="">
                    <h4>Start Your Journey?</h4>
                    <p>There are many variations of passages of Lorem Ipsum available</p>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="body-cont3 ">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 decp">
                <ul>
                    <li>
                        <h6>english conversation course</h6>
                        <h2><a href="#">Build your media and public presence</a></h2>
                        <p>consectetur adipisicing elit se eiusmod tempor incididunt ut labore et dolore magna asin lute
                            enim</p>
                        <h3>$254 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h3>
                    </li>
                    <li>
                        <h6>exam english course</h6>
                        <h2><a href="#">Build your media and public presence</a></h2>
                        <p>consectetur adipisicing elit se eiusmod tempor incididunt ut labore et dolore magna asin lute
                            enim</p>
                        <h3>$254 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h3>
                    </li>
                    <li>
                        <h6>business english course</h6>
                        <h2><a href="#">Build your media and public presence</a></h2>
                        <p>consectetur adipisicing elit se eiusmod tempor incididunt ut labore et dolore magna asin lute
                            enim</p>
                        <h3>$254 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h3>
                    </li>
                    <li>
                        <h6>Kid’s english course</h6>
                        <h2><a href="#">Build your media and public presence</a></h2>
                        <p>consectetur adipisicing elit se eiusmod tempor incididunt ut labore et dolore magna asin lute
                            enim</p>
                        <h3>$254 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h3>
                    </li>
                </ul>
            </div>
            <div class="col-lg-4 side-bar">
                <img src="<?php echo e(asset('frontend/images/home-img6.png')); ?>" alt="">
                <h6>Our Courses</h6>
                <h2>Start Learning Today</h2>
                <p>Doluptas sit atur aut odit aut fugit, sed quia consequuntur magni res eos qui ratione voluptatem
                    sequi nesciunt.</p>
                <a href="#">View All Courses</a>
            </div>
        </div>
    </div>
</section>

<section class="body-cont4">
    <img src="<?php echo e(asset('frontend/images/home-img7.jpg')); ?>" alt="">
    <div class="wrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-5">
                <h6>We Are Professional And Expert</h6>
                <h2>Let’s See Online Education</h2>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                    doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo invenw tore veritatis et quasi
                    architecto beatae vitae dicta.</p>
                <a href="#">Register Now</a>
            </div>
        </div>
    </div>
    </div>
</section>

<section class="body-cont5">
    <div class="container">
       <div class="row">
           <div class="col-lg-12">
               <h2>What Our Students Say</h2>
               <div class="students-say owl-carousel">
                   <div class="item">
                       <div class="row align-items-center">
                           <div class="col-lg-5 col-md-5 pr-lg-5">
                               <div class="img-wrap">
                               <img src="<?php echo e(asset('frontend/images/home-img8.jpg')); ?>" alt="">
                               </div>
                           </div>
                           <div class="col-lg-7 col-md-7">
                               <p>Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus. Fusce volutpat gravida augue eget hendrerit. Mauris sollicitudin cursus orci, vel pellentesque nisl pretium vel. sed augue malesuada, porttitor urna vel cursus eros.</p>
                               <h5>John Deo</h5>
                               <h6>Ui/Ux Design</h6>
                           </div>
                       </div>
                   </div>
                   <div class="item">
                       <div class="row align-items-center">
                       <div class="col-lg-5 col-md-5 pr-lg-5">
                               <div class="img-wrap">
                               <img src="<?php echo e(asset('frontend/images/home-img8.jpg')); ?>" alt="">
                               </div>
                           </div>
                           <div class="col-lg-7 col-md-7">
                               <p>Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus. Fusce volutpat gravida augue eget hendrerit. Mauris sollicitudin cursus orci, vel pellentesque nisl pretium vel. sed augue malesuada, porttitor urna vel cursus eros.</p>
                               <h5>John Deo</h5>
                               <h6>Ui/Ux Design</h6>
                           </div>
                       </div>
                   </div>
                   <div class="item">
                       <div class="row align-items-center">
                       <div class="col-lg-5 col-md-5 pr-lg-5">
                               <div class="img-wrap">
                               <img src="<?php echo e(asset('frontend/images/home-img8.jpg')); ?>" alt="">
                               </div>
                           </div>
                           <div class="col-lg-7 col-md-7">
                               <p>Fusce sit amet suscipit augue. Nulla in justo vitae arcu fermentum sodales ut a purus. Fusce volutpat gravida augue eget hendrerit. Mauris sollicitudin cursus orci, vel pellentesque nisl pretium vel. sed augue malesuada, porttitor urna vel cursus eros.</p>
                               <h5>John Deo</h5>
                               <h6>Ui/Ux Design</h6>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
    </div>
</section>
<section class="body-cont6">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 title-sec text-center">
                <h6>Blogs</h6>
                <h2>Our Latest Blogs</h2>
                <p>Doluptas sit atur aut odit aut fugit, sed quia consequuntur magni res eos qui ratione voluptatem sequi nesciunt.</p>
            </div>
            <div class="col-lg-6 col-md-7 sec1">
                <div class="img-wrap">
                    <img src="<?php echo e(asset('frontend/images/home-img10.jpg')); ?>" alt="">
                    <div class="decp">
                        <h3>Fusce sit amet suscipit augue. Nulla in justo vitae arcu</h3>
                        <h4>20 Sep, 2021 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-5 sec2">
                <div class="row">
                    <div class="col-lg-4">
                        <img src="<?php echo e(asset('frontend/images/home-img11.jpg')); ?>" alt="">
                    </div>
                    <div class="col-lg-8">
                        <h4>Fusce sit amet suscipit augue. Nulla in justo vitae arcu</h4>
                        <h5>20 Sep, 2021 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <img src="<?php echo e(asset('frontend/images/home-img12.jpg')); ?>" alt="">
                    </div>
                    <div class="col-lg-8">
                        <h4>Fusce sit amet suscipit augue. Nulla in justo vitae arcu</h4>
                        <h5>20 Sep, 2021 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <img src="<?php echo e(asset('frontend/images/home-img13.jpg')); ?>" alt="">
                    </div>
                    <div class="col-lg-8">
                        <h4>Fusce sit amet suscipit augue. Nulla in justo vitae arcu</h4>
                        <h5>20 Sep, 2021 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <img src="<?php echo e(asset('frontend/images/home-img14.jpg')); ?>" alt="">
                    </div>
                    <div class="col-lg-8">
                        <h4>Fusce sit amet suscipit augue. Nulla in justo vitae arcu</h4>
                        <h5>20 Sep, 2021 <a href="#">View Details <i class="fal fa-long-arrow-right"></i></a></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/layouts/home.blade.php ENDPATH**/ ?>