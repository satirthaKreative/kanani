<script src="<?php echo e(asset('frontend/studentDashboard/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/studentDashboard/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/studentDashboard/js/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/studentDashboard/js/jquery.slimNav_sk78.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/easy-pie-chart/2.1.6/jquery.easypiechart.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script><?php /**PATH D:\project's\KMProject\kananiEducation\resources\views/front/pages/dashboard-student/inc/footer.blade.php ENDPATH**/ ?>